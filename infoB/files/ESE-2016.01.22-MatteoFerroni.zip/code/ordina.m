function [v] = ordina(v, confronta)
	continua = 1;
	while continua
		continua = 0;
        
		for i = 1:length(v)-1
            confronto = confronta(v(i), v(i+1));
            
			if (confronto)
                v = scambiaPosizioni(v, i);
                continua = 1;
            end
            
		end
    end

