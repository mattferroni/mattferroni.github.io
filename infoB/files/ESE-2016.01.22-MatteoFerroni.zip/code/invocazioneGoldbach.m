% Esempio di invocazione goldbach
numero = 936;

primo = @(x) numeroPrimoIterativa(x);
goldbach(numero, primo);

primo = @(x) numeroPrimoRicorsiva(x,2);
goldbach(numero, primo);

primo = @(x) numeroPrimoVettoriale(x);
goldbach(numero, primo);

