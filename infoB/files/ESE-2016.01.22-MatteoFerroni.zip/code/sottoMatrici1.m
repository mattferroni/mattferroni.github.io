function [M] = sottoMatrici1(n)
 
    if(n == 1)
        M = ones(2,2);
    else
        M = sottoMatrici1(n-1);
        r = ones(1, size(M, 2)) * n;
        M = [r; M ; r];
        c = ones(size(M, 1), 1) * n;
        M = [c M c];
    end
    
