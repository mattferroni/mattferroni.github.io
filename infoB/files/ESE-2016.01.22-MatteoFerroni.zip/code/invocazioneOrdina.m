% Esempio di invocazione di ordina
maggiore = @(a,b) a < b ; 
minore = @(a,b) a > b ;

v = [2 5 7 4 9 3 6 1 8];

ordina(v, maggiore)



ordina(v, minore)



