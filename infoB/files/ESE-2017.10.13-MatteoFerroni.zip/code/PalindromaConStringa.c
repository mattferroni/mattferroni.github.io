#include <stdio.h>
#define MAXLEN 100

int main(){
    char lettere[MAXLEN];
    int max = 0;
    char c = 'a';
    int i, j;
    int found = 1;

    printf("Inserire una stringa:\n");
    scanf("%s", lettere);

    for(max = 0; c!='\0'; max++){
        c = lettere[max];
    }

    i=0;
    j=max-2;
    while(found == 1 && i<j){
        if(lettere[i] != lettere[j]){
            found = 0;
        }
        i++;
        j--;
    }

    if(found == 1)
        printf("la stringa e' palindroma\n");
    else
        printf("la stringa non e' palindroma\n");

    return 0;
}
