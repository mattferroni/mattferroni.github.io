function [response] = confronta(a,b)
	% torna vero se a � MINORE di b,
    % provocando ordinamento DECRESCENTE
    response = a < b ; 
    
    % torna vero se a � MAGGIORE di B
    % provocando ordinamento CRESCENTE
    % response = a > b ;
end

