#include <stdio.h>
int main()
{
	int i,j;
 
	// Utilizzo un array di 100 elementi
	// Se il contenuto nella cella i-esima è 1, il numero è primo
	int array[100];
 
	// Inizializzazione dell'array: "tutti i numeri sono primi"
	for (i=0;i<100;i++)
		array[i]=1;
 
	// Si procede al setaccio: ignoro i primi due elementi (numeri 0 e 1)
	for (i=2;i<100;i++) {
		// Se il numero è ancora marcato come primo (non è multiplo dei suoi precedenti)
		if(array[i]==1) {
			// Marco come "non primi" tutti i suoi multipli
			for (j=2; j<=(100/i); j++){
				array[i*j] = 0;
			}
		}
	}
 
	// Si stampano i primi 100 numeri primi
	printf("\nNumeri primi < 100: ");
 
	for (i=1;i<100;i++){
		if(array[i]==1)
			printf("\t%d", i);
	}
	return 0;
}