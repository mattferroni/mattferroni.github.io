
rimasti = 2:100;
setacciati = [];

while ~isemplty(rimasti)
    candidato = rimasti(1);
    setacciati = [setacciati rimasti(1)];
    rimasti = rimasti(logical(mod(rimasti,candidato)));
end


