% Esempio di invocazione di ordina
v = [2 5 7 4 9 3 6 1 8];

v_ord = ordina(v);