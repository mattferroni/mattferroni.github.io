function [response] = primo(x)
	% De-commenta quella che vuoi usare ;)
    % response = numeroPrimoIterativa(x);
    % response = numeroPrimoRicorsiva(x,2);
    response = numeroPrimoVettoriale(x);
end

