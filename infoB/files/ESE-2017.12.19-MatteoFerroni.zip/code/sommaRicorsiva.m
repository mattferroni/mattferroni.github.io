function x = sommaRicorsiva(valore, passo)
    if passo == 0
        x = valore;
    else
        x = sommaRicorsiva(valore + 1, passo-1);
    end
end

