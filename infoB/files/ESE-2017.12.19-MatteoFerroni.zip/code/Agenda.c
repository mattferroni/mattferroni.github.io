#include <stdio.h>
#include <string.h>

#define GIORNI 5
#define ORE 10

int main()
{
    typedef enum {LIBERO, PRENOTATO, ESEGUITO} Stato;
    typedef struct {
        char paziente[40];
        char tipoPrestazione[100];
        char note[75];
        float pagato;
        Stato stato;
    } Prenotazione;

    Prenotazione agendaSett[GIORNI][ORE];
    int giorno = 0, ora = 0;
    char scelta;
    int giornoSel = -1, oraSel = -1;

    for(giorno = 0; giorno < GIORNI; giorno++) {
        for(ora = 0; ora < ORE; ora++) {
            strcpy(agendaSett[giorno][ora].paziente, "");
            strcpy(agendaSett[giorno][ora].tipoPrestazione, "");
            strcpy(agendaSett[giorno][ora].note, "");
            agendaSett[giorno][ora].pagato = 0.0;
            agendaSett[giorno][ora].stato = LIBERO;
        }
    }

    do {
        printf("-------------------------------------------\n");
        printf("Opzioni disponibili:\n");
        printf("Inserisci appuntamento (i)\n");
        printf("Visualizza appuntamenti di un giorno (v)\n");
        printf("Inserisci pagamento (p)\n");
        printf("Stampa ricevuta (s)\n");
        printf("Operazione scelta: ");
        scanf("%c", &scelta);
        printf("-------------------------------------------\n");

        switch(scelta) {

            case 'i':
                printf("Inserimento nuovo appuntamento:\n");
                do {
                    printf("Inserisci giorno (1 - %d): ", GIORNI);
                    scanf("%d", &giornoSel);
                }while((giornoSel < 1) || (giornoSel > GIORNI));
                giornoSel = giornoSel - 1;
                do{
                    printf("Inserisci ora (8 - %d): ", ORE + 8 - 1);
                    scanf("%d", &oraSel);
                }while((oraSel < 8) || (oraSel >= ORE + 8 ));
                oraSel = oraSel - 8;
                scanf("%*c"); //fflush(stdin);
                if(agendaSett[giornoSel][oraSel].stato == LIBERO) {
                    printf("Inserisci nome paziente: ");
                    gets(agendaSett[giornoSel][oraSel].paziente);
                    printf("Inserisci tipo di prestazione: ");
                    gets(agendaSett[giornoSel][oraSel].tipoPrestazione);
                    printf("Inserisci eventuali note: ");
                    gets(agendaSett[giornoSel][oraSel].note);
                    agendaSett[giornoSel][oraSel].stato = PRENOTATO;
                } else {
                    printf("Impossibile completare l'operazione; per l'orario scelto e' gia' presente una prenotazione.\n");
                    break;
                }

            case 'v':

                if((giornoSel < 0)) {
                    do {
                        printf("Inserisci giorno (1 - %d): ", GIORNI);
                        scanf("%d", &giornoSel);
                    }while((giornoSel < 1) || (giornoSel > GIORNI));
                    giornoSel = giornoSel - 1;
                    scanf("%*c"); //fflush(stdin);
                }
                printf("Appuntamenti del giorno %d:\n", giornoSel + 1);
                for(ora = 0; ora < ORE; ora++) {
                    if(agendaSett[giornoSel][ora].stato == LIBERO) {
                        printf("- Alle %d non sono previsti appuntamenti\n", ora + 8);
                    } else if(agendaSett[giornoSel][ora].stato == PRENOTATO) {
                        printf("- Alle %d il signor %s ha prenotato una %s", ora + 8, agendaSett[giornoSel][ora].paziente, agendaSett[giornoSel][ora].tipoPrestazione);
                        if(strlen(agendaSett[giornoSel][ora].note) > 0) {
                            printf(" (NOTE: %s)\n", agendaSett[giornoSel][ora].note);
                        } else {
                            printf("\n");
                        }
                    } else if(agendaSett[giornoSel][ora].stato == ESEGUITO) {
                        printf("- Alle %d il signor %s ha fatto una %s, e ha pagato %f\n", ora + 8, agendaSett[giornoSel][ora].paziente, agendaSett[giornoSel][ora].tipoPrestazione, agendaSett[giornoSel][ora].pagato);
                    }
                }
                giornoSel = -1;
                break;

            case 'p':
                printf("Registra pagamento:\n");
                do {
                    printf("Inserisci giorno (1 - %d): ", GIORNI);
                    scanf("%d", &giornoSel);
                }while((giornoSel < 1) || (giornoSel > GIORNI));
                giornoSel = giornoSel - 1;
                do{
                    printf("Inserisci ora (8 - %d): ", ORE + 8 - 1);
                    scanf("%d", &oraSel);
                }while((oraSel < 8) || (oraSel >= ORE + 8 ));
                oraSel = oraSel - 8;
                scanf("%*c"); //fflush(stdin);
                if(agendaSett[giornoSel][oraSel].stato != PRENOTATO) {
                    printf("Per il giorno e l'ora selezionati non risulta nessun appuntamento, quindi non e' possibile effettuare un pagamento.\n");
                    break;
                } else {
                    printf("Alle %d il signor %s ha fatto una %s, e paga: ", oraSel + 8, agendaSett[giornoSel][oraSel].paziente, agendaSett[giornoSel][oraSel].tipoPrestazione);
                    scanf("%f", &agendaSett[giornoSel][oraSel].pagato);
                    agendaSett[giornoSel][oraSel].stato = ESEGUITO;
                }

            case 's':
                printf("Stampa ricevuta:\n");
                if((giornoSel < 0) || (oraSel < 0)) {
                    do {
                        printf("Inserisci giorno (1 - %d): ", GIORNI);
                        scanf("%d", &giornoSel);
                    }while((giornoSel < 1) || (giornoSel > GIORNI));
                    giornoSel = giornoSel - 1;
                    do{
                        printf("Inserisci ora (8 - %d): ", ORE + 8 - 1);
                        scanf("%d", &oraSel);
                    }while((oraSel < 8) || (oraSel >= ORE + 8 ));
                    oraSel = oraSel - 8;
                }
                scanf("%*c"); //fflush(stdin);
                if(agendaSett[giornoSel][oraSel].stato != ESEGUITO) {
                    printf("Per il giorno e l'ora selezionati non risulta nessun pagamento.\n");
                } else {
                    printf("Il giorno %d alle %d il signor %s ha fatto una %s, e ha pagato %.2f\n", giornoSel + 1, oraSel + 8, agendaSett[giornoSel][oraSel].paziente, agendaSett[giornoSel][oraSel].tipoPrestazione, agendaSett[giornoSel][oraSel].pagato);
                }
                giornoSel = -1;
                oraSel = -1;
                break;

            case 'q':
                printf("\nEsco dall'agenda, buon lavoro!\n");
                break;
            default:
                printf("\nOperazione non consentita, inserire un'operazione valida.\n");

        }
    }while(scelta != 'q');

    return 0;
}
