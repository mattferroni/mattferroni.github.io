% Rappresentiamo un polinomio con un vettore contenente i suoi coefficienti,
% dal termine di grado massimo a quello di grado minimo. Si noti che un polinomio di grado
% n corrisponde a un vettore di lunghezza n+1

% Esempio: 3x4 + 5x2 + 2x +7 (grado 4) corrisponde al vettore [3 0 5 2 7] (lunghezza 5).

% Scrivere una funzione ricorsiva di nome derivata che:
%	1) Riceva in ingresso un vettore che rappresenta un polinomio e un valore n
% 	2) Restituisca un vettore che rappresenta la derivata n-esima del polinomio

% Per calcolare la derivata prima del polinomio applicare la comune regola di derivazione per i polinomi
% Calcolare la derivata n-esima come la derivata prima della derivata (n-1)-esima

% Mostrare lo schema delle chiamate ricorsive sulla derivata terza del polinomio
%	5x^5 + 4x^4 + 3x^3 + 2*x^2 + x^1 + 1

function[der] = derivata (pol, n)

% Caso base: calcolo della derivata prima
if n==1
    
	% Vettore con gli esponenti dei singoli monomi
	% Es. per 2x^3 + x^2 + 3 --> esp = [3 2 1]
	esp = [length(pol)-1 : -1 : 1]
    
	% Calcolo della derivata prima:
	% Es. per il polinomio precedente:
	% [3 2 1].*[2 1 0] = [6 2 0]
	der = esp.*pol(1:length(pol)-1)
    
else
    
	% Passo ricorsivo: derivata (n-1)-esima della derivata prima
	der = derivata(derivata(pol, n-1), 1)
    
end

