% Carico il file che contiene la definizione dell'array prezzi
load 'prezzi'

prezzi1 = prezzi(1,:)

prezziBrandMin = min(prezzi)
prezziBrandMax = max(prezzi)

prezziGiornoMin = min(prezzi, [], 2)
prezziGiornoMax = max(prezzi, [], 2)

% Calcolo la variazione del prezzo come la differenza tra 
% i prezzi minimi e massimi nel mese
diffBrand = prezziBrandMax - prezziBrandMin

% Massima variazione
maxDiff = max(diffBrand)

% Compagnia con massima variazione
maxBrand = find(diffBrand == maxDiff)


g = input('inserire il giorno ');

%trova il minimo prezzo del giorno g
minp = min(prezzi(g,:));

%trova la compagnia/compagnie con prezzo minimo
comp = find(prezzi(g,:)==minp);

disp(['La pi� conveniente il giorno ' num2str(g) ' era/erano la compagnia/compagnie ' mat2str(comp) ' al prezzo di ' num2str(minp)]) 



