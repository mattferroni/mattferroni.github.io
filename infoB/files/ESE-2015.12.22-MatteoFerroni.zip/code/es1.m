
% Scrivere un programma che permetta all'utente di inserire un vettore di numeri interi. 
vett = input('Inserisci un vettore: ');

% Dopo aver verificato che l'array inserito sia numerico, effettuare i seguenti controlli:
if isnumeric(vett)

	% Verificare se tutti i numeri sono positivi
	if all(vett > 0)
		disp('tutti i numeri sono positivi');
	else
		disp('non tutti i numeri sono positivi');
	end

	% Verificare se esiste un numero negativo
	if any(vett <0)
		disp('esiste un numero negativo');
	else
		disp('non esiste alcun numero negativo');
	end

	% Applicare la radice quadrata a tutti i valori: ci sono dei valori complessi?
	sqrt_vett = sqrt(vett)
	if isreal(sqrt_vett)
		disp('non esistono valori complessi');
	else
		disp('esistono valori complessi');
	end

	% Verificare se tutti i numeri sono pari e trovarne le posizioni
	vett_mod = mod(vett,2);
	if(all(vett_mod==0))
		disp('tutti i numeri sono pari');
	else
		disp('non tutti i numeri sono pari');
	end
	pos_pari = find(1-vett_mod);
    disp('I numeri pari sono in posizione: ');
    disp(pos_pari);

	% Verificare se esiste un numero dispari
	if any(vett_mod),
		disp('esiste almeno un numero dispari');

		% Contare i numeri dispari se esistono e dire in che posizioni sono
		count_dispari = sum(vett_mod);
		disp(['i numeri dispari sono ' num2str(count_dispari)]);
		pos_dispari = find(vett_mod);
		disp('i numeri dispari sono in posizione: ');
		disp(pos_dispari);
	else
		disp('non esistono numeri dispari');
	end
else
	disp('Devi inserire un array numerico');
end	