function [minp comp] = conviene(prezzi, g)
  
  %trova il minimo prezzo del giorno g
  minp = min(prezzi(g,:));
  
  %trova la compagnia/compagnie con prezzo minimo
  comp = find(prezzi(g,:)==minp);
  
 