function ris=palindroma(stringa)
  % Ricavo la stringa invertita
  stringa_r = stringa(end:-1:1);
  
  % Se le stringhe sono uguali, la stringa palindroma
  if all(stringa == stringa_r)
    ris=true;
  else
    ris=false;
  end
