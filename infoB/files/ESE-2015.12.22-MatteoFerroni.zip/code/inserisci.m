function v_ord = inserisci(v,e)
    v_ord = [v(v<=e) e v(v>e)];
    
    