more = input('vuoi inserire valori altimetrici? (s/n)');
ii=1;
while more=='s'
    arch(ii).altitudine = input('altitudine ');
    arch(ii).longitudine = input('longitudine ');
    arch(ii).latitudine = input('latitudine ');
    ii = ii+1;
    more = input('vuoi inserire altri valori altimetrici? (s/n)');
end

jj=1;
for ii=1:length(arch)
	% attenzione: la condizione deve essere scritta sulla stessa linea?
    if arch(ii).latitudine>=10&&arch(ii).latitudine<=80 && 
       arch(ii).longitudine>=30&&arch(ii).longitudine<=60 
        elemSelez(jj) = arch(ii).altitudine;
        jj=jj+1;
    end
end
disp(['la media degli elementi selezionati e` ' num2str(mean(elemSelez))])

