a = [5 2 4 6 1 3]

a_ord = a(1);
for i=2:length(a)
    a_ord = inserisci(a_ord,a(i));
end

a_ord


