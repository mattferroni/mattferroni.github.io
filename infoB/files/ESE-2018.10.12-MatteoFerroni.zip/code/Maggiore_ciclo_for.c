#include <stdio.h>
int main () {
	int max=0;
	int N, val, cont;

	printf("Quanti numeri vuoi inserire? ");
	scanf("%d",&N);

	for(cont=0; cont < N; cont++){
		printf("Inserisci il nuovo numero (positivo): ");
		scanf("%d",&val);
		if (val > max)
			max = val;
	}
	printf("Il massimo e' = %d \n", max);
	return 0;
}