#include <stdio.h>
int main () {
	int N;
	int max=0;
	int val;
	int cont = 0;

	printf("Quanti numeri vuoi inserire? ");
	scanf("%d",&N);

	while(cont < N){
		printf("Inserisci il nuovo numero (positivo): ");
		scanf("%d",&val);
		if (val > max)
			max = val;
        cont++;
	}
	printf("Il massimo e' = %d \n", max);
	return 0;
}
