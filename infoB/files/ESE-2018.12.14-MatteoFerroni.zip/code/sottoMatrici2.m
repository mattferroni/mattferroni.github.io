function [matrRis]=sottoMatrici2(n)

    if n==1
        matrRis=ones(2);
    else
        matrRis=n*ones(2*n);
        matrRis(2:2*n-1,2:2*n-1)=sottoMatrici2(n-1);
    end

    