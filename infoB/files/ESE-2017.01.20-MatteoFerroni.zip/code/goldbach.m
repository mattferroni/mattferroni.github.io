function [x,y] = goldbach(n, primo)
    
    if (mod(n,2) ~= 0 || n<=2)
        return
    end
    
    for x=2:n
        if (primo(x))
            for y=2:x
                if (primo(y))
                    if ((x+y) == n)
                        display([num2str(x) ' + '  num2str(y)])
                        return 
                    end
                end
            end
        end
    end
    
    display 'congettura errata *_*'
