#include <stdio.h>

int main(){

  int n, primo, i;

  printf("Inserisci un numero: ");
  scanf("%d",&n);

  primo=1;

  if(n==1){
    primo = 0;
  }

  for(i=2;i<=n/2;i++){
    if(n%i==0){
      primo=0;
    }
  }

  if(primo == 1){
    printf("%d e' un numero primo\n",n);
  }else{
    printf("%d non e' un numero primo\n",n);
  }

  return 0;
}


