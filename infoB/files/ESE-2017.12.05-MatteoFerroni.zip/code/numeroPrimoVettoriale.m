function [ris] = numeroPrimoVettoriale(x)
    divisori = 2:sqrt(x);
    resti = rem(x,divisori);
    maschera = (resti == 0);
    ris = ~any(maschera);
    
    % Soluzione compatta
    % ris = any(rem(x,2:sqrt(x)) == 0);
