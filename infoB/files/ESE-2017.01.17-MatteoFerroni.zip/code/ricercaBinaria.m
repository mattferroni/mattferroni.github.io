function val = ricercaBinaria(v, cercato, limSinistra, limDestra)

	elementoMedio = floor((limDestra + limSinistra)/2);

    if (v(elementoMedio) == cercato)
        val = elementoMedio;
    else
        
		if (v(elementoMedio) > cercato)
			limDestra = elementoMedio;
		else
			limSinistra = elementoMedio;
        end
        
        val = ricercaBinaria(v, cercato, limSinistra, limDestra);
    
    end

    