function [ris] = numeroPrimoRicorsiva(x,y)  
    if y>sqrt(x)
        ris = 1;
    else
        ris = (~(~rem(x,y)))*numeroPrimoRicorsiva(x,y+1);
    end
    