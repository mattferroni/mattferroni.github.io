function r = mag(f, v)
	r = v(1);
	for i=1:length(v)
		if (f(v(i)) > f(r))
			r = v(i);
		end
	end
end

