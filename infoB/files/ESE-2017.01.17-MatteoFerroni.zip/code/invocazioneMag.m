% Esempio di uso di mag

v = 2:100;

f = @(x) log(x);
risultato = mag(f,v)

g = @(x) -x^2 + 40*x;
risultato = mag(g,v)

