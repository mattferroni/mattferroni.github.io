function [ris] = numeroPrimoIterativa(x)  
    ris=1;
    for y=2:sqrt(x)
        ris = ris*(~(~rem(x,y)));
    end
