function [ v ] = scambiaPosizioni( v, pos )
    a = v(pos);
    b = v(pos+1);
    v(pos) = b;
    v(pos+1) = a;
end


