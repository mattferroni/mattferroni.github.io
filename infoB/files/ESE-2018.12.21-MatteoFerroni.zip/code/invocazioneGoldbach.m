% Esempio di invocazione goldbach
numero = 934;
goldbach(numero);