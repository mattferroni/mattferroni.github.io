function x = esponenzialeRicorsivo(valore, passo)
    if passo == 0
        x = 1;
    else
        x = valore * esponenzialeRicorsivo(valore, passo-1);
    end
end

