function x = prodottoRicorsivo(valore, passo)
    if passo == 0
        x = 0;
    else
        x = valore + prodottoRicorsivo(valore, passo-1);
    end
end

