a = [10 2 -6 9 2 5]

curr = min(a)
pos = find(a == curr)

filtro_n = a==curr
filtro = ones(1,length(a)) - filtro_n 
a1 = a(logical(filtro)) 

a_ord = curr

while length(a1) > 0
     curr = min(a1)
     pos = find(a1 == curr)
     
     filtro_n = a1==curr
     filtro = ones(1,length(a1)) - filtro_n 
     a1 = a1(logical(filtro))
     
     a_ord = [a_ord; curr*ones(length(pos),1)]
end

a_ord

