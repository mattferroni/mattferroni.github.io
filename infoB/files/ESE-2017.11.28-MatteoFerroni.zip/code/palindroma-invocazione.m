
palindroma('ingegni')

palindroma('itopinonavevanonipoti')


