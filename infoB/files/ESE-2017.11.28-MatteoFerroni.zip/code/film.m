% Inserimento films

stopInput='S';
count=1;

while(stopInput=='S')

    films(count).titolo = input('Inserisci il titolo: ');
    films(count).anno = input('Inserisci anno: ');
    films(count).voto = input('Inserisci il voto: ');
     
    count = count + 1;
    
    stopInput = input('Vuoi inserire altri film? (S/N) ');
    
end

% Numero totale di film con voto superiore a 6
sum([films.voto] > 6)

% Film prodotti tra il 2002 ed il 2005
idx = find([films.anno] > 2002 & [films.anno] < 2005);

% Stampa titoli e voti separatamente
films(idx).titolo
films(idx).voto

% Stampa titolo e voto affiancati
for i=idx
    display([films(i).titolo ' ' num2str(films(i).voto)])
end

