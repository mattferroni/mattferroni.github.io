/**
Scrivere un programma che legge una matrice quadrata di dimensioni specificate dall'utente (al massimo 10 righe e 10 colonne):
- calcolare la somma dei valori sulla diagonale principale
- calcolare la somma dei valori sopra la diagonale principale
- calcolare la somma dei valori sotto la diagonale principale
**/


#include <stdio.h>
#include <string.h>

#define MAXDIM 10

int main(){
	int matrice[MAXDIM][MAXDIM];
	int righe[MAXDIM];
	int colonne[MAXDIM];
	int sup = 0, inf = 0, diag = 0, dim = 0, i = 0, j = 0;

	do{
		printf("inserire il numero di righe della matrice (massimo 10)\n");
		scanf("%d", &dim);
		}while(dim < 1 || dim > 10);

	for(i=0; i<dim; i++){
 		for(j=0; j<dim; j++){
 			printf("inserire un numero per la posizione (%d,%d)\n", i,j);
 			scanf("%d", &matrice[i][j]);
 		}
 	}

 	/** stampare la matrice a video e calcolare le somme di righe, colonne,
 		diagonale e triangolari superiori ed inferiori **/
	for(i=0; i<dim; i++){
		for(j=0; j<dim; j++){
			printf("%d ", matrice[i][j]);

			righe[i] = righe[i] + matrice[i][j];

			colonne[j] = colonne[j] + matrice[i][j];

			if(i==j)
 				diag = diag + matrice[i][j];
 			else if (i < j)
 				sup = sup + matrice[i][j];
 			else
 				inf = inf + matrice[i][j];
		}
		printf("\n");
	}

	/** stampare le somme delle righe**/
	for(i=0; i<dim; i++){
		printf("somma riga %d = %d\n", i+1, righe[i]);
	}

	/** stampare le somme delle colonne**/
	for(j=0; j<dim; j++){
		printf("somma colonna %d = %d\n", j+1, colonne[j]);
	}

 	printf("la somma delle diagonale e': %d\n", diag);
 	printf("la somma della parte superiore alla diagonale e': %d\n", sup);
 	printf("la somma della parte inferiore alla diagonale e': %d\n", inf);

	return 0;
}
