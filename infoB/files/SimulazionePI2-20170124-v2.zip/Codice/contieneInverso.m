function r = contieneInverso(v1,v2)
    if (isempty(v2))
        r = 1;
    else if (isempty(v1))
        r = 0;
    else
        if (v1(1) == v2(end))
            r = contieneInverso(v1(2:end),v2(1:end-1));
        else
            r = contieneInverso(v1(2:end),v2(1:end));
        end
    end
end