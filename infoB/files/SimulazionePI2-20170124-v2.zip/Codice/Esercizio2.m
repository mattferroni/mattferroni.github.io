V1 = input('inserire il vettore V1: ');
V2 = input('inserire il vettore V2: ');

r = contieneInverso(V1,V2);

if (r)
    disp(['tutti gli elementi di V2 sono contenuti in ordine inverso in V1']);
else
    disp(['gli elementi di V2 non sono contenuti in ordine inverso in V1']);
end