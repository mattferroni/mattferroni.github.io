
% Semplice script per la generazione di un archivio d'esempio
for ii = 1:1200
    archivio(ii).nome = ['Utente ' num2str(ii)];
    archivio(ii).eta = ceil(rand * 65);
    
    if rand > 0.5
        archivio(ii).sesso = 'M';
    else
        archivio(ii).sesso = 'F';
    end
        
    test = rand;
    if test < 0.3
        archivio(ii).ore = [6 7 6 7 5 6 7 6 7 5 6 7 6 7 5 6 7 6 7 5];
    elseif test < 0.6
        archivio(ii).ore = [8 9 8 7 8 8 9 8 7 8 8 9 8 7 8 8 9 8 7 8];
    elseif test < 0.8
        archivio(ii).ore = [11 12 11 10 12 11 12 11 10 12 11 12 11 10 12 11 12 11 10 12];
    else 
        archivio(ii).ore = [13 14 15 14 13 13 14 15 14 13 13 14 15 14 13 13 14 15 14 13];
    end
    
    test = rand;
    if test < 0.3
        archivio(ii).contratti = 10
    elseif test < 0.6
        archivio(ii).contratti = 25
    elseif test < 0.9
        archivio(ii).contratti = 48
    else 
        archivio(ii).contratti = 55
    end
end

% Salvo l'archivio corrente su file
save prod.mat;

% Pulisco la memoria
clc;
clear;

% Carico il contenuto del file in memoria
load prod.mat;

% Calcolo la media e lo stipendio
for ii = 1:length(archivio)
    archivio(ii).media = mean(archivio(ii).ore);
    
    if archivio(ii).media < 7
        % se un dipendente ha lavorato in media meno di 7 ore al giorno 
        % la paga � di 5? all?ora
        euro_ora = 5;
    elseif archivio(ii).media < 12
        % se ha lavorato da 7 a 12 ore in media, � di 10? all?ora;
        euro_ora = 10;
    else
        % altrimenti � di 6? all?ora;
        euro_ora = 6;
    end
    
    archivio(ii).stipendio = sum(archivio(ii).ore.*euro_ora);
    
    if archivio(ii).contratti >= 48
        archivio(ii).stipendio = archivio(ii).stipendio + 500;
    end
end

% stampi a video il numero dei dipendenti che, pur lavorando pi� di 12 ore 
% al giorno (in media), guadagnano meno della media dei dipendenti;
media_stipendi = mean([archivio.stipendio]);
num_dipendenti_sfortunati = sum([archivio.stipendio]<media_stipendi & [archivio.media]>12);
disp(['Numero dipendenti sfortunati: ' num2str(num_dipendenti_sfortunati)]);

% dica se � vero che le donne al di sotto dei 35 anni sono in grado di 
% stipulare in media pi� contratti rispetto agli uomini che hanno pi� di 35 anni;
media_contratti_F_under_35 = mean([archivio([archivio.sesso]=='F' & [archivio.eta]<35).contratti]);
media_contratti_M_over_50 = mean([archivio([archivio.sesso]=='M' & [archivio.eta]>50).contratti]);

if media_contratti_F_under_35 > media_contratti_M_over_50
    disp('Le donne al di sotto dei 35 anni vincono!');
else
    disp('Gli uomini che hanno pi� di 35 anni vincono!');
end

% stampi gli stipendi medi delle donne e degli uomini che hanno pi� di 50 anni.
stipendio_medio_F_over_50 = mean([archivio([archivio.sesso]=='F' & [archivio.eta]>50).stipendio]);
stipendio_medio_M_over_50 = mean([archivio([archivio.sesso]=='M' & [archivio.eta]>50).stipendio]);

disp(['Le donne over 50 guadagnano, in media: ' num2str(stipendio_medio_F_over_50) ' euro al mese']);
disp(['Gli uomini over 50 guadagnano, in media: ' num2str(stipendio_medio_M_over_50) ' euro al mese']);
                 
                 
