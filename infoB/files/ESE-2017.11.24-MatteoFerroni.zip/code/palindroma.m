stringa = input('Inserire una stringa: ');

% Ricavo la stringa invertita
stringa_r = stringa(end:-1:1);
  
% Se le stringhe sono uguali, la stringa palindroma
if all(stringa == stringa_r)
	disp('La stringa � palindroma!');
else
    disp('La stringa NON � palindroma!')
end
