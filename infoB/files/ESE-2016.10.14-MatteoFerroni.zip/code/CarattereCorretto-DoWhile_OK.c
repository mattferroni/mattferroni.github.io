/**
  * info B 
  *
  * Si scriva un programma che richieda 
  * l'inserimento di un carattere e che
  * quindi ne mostri la sua "versione
  * maiuscola". Verificando la correttezza
  * del carattere in ingresso.
  * Se il carattere non e' corretto, questo
  * viene richiesto nuovamente.
*/

#include <stdio.h>

int main () {
  char carattere;
  
  do{
    printf("\n\n Inserisci un carattere minuscolo: ");
    scanf(" %c",&carattere);
  } while (!(('a' <= carattere) && (carattere <='z')));

  printf("Il carattere inserito e' %c\n",carattere);
  printf("La sua rappresentazione maiuscola e' %c\n", carattere-32);
  
  return 0;
}
