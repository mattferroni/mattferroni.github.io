#include <stdio.h>

int main () {
    int i, n, fattoriale = 1;

    printf("Di quale numero vuoi calcolare il fattoriale? ");
    scanf("%d",&n);

    i=n;
    while(i>1){
        fattoriale = fattoriale * i;
        i--;
    }

    printf("\nIl fattoriale di %d e' %d \n", n, fattoriale);
    return 0;
}
