#include <stdio.h>

int main () {
    int i, n, fattoriale = 1;

    printf("Di quale numero vuoi calcolare il fattoriale? ");
    scanf("%d",&n);

    for(i=n; i > 1; i--){
        fattoriale = fattoriale * i;
    }

    printf("\nIl fattoriale di %d e' %d \n", n, fattoriale);
    return 0;
}
