#include <stdio.h>
#define DIMA 10
#define DIMB 5
int main()
{
	int i;
	int a[DIMA];
	int b[DIMB];
 
	// Leggo l'array A
	for (i = 0; i < DIMA; i++){
		printf("\nInserisci i valore %d per l'array a: ", i);
		scanf("%d",&a[i]);
	}
 
	// Stampo l'array A
	printf("\narray a = ");
	for (i = 0; i < DIMA; i++)
		printf("%d ", a[i]);
 
	// Scrivo nell'array B
	for (i = 0; i < DIMB; i++)
		b[i] = a[DIMA - i - 1];
	printf("\narray a riversato = ");
 
	for (i = 0; i < DIMB; i++){
		printf("%d ", b[i]);
	}
	printf("\n");
	return 0;
}