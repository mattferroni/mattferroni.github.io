#include <stdio.h>
#define MAXLEN 100

int main(){
    char lettere[MAXLEN], max = 0;
    char c;
    int i, j;
    int found = 1;

    do{
        printf("inserire un carattere, #per termianre\n");
        scanf("\n%c", &c);
        if((c >= 'a') && (c <= 'z')){
            lettere[max] = c;
            max++;
        }
    }while(c!='#' && max < MAXLEN);

    i=0;
    j=max-1;
    while(found == 1 && i<j){
        if(lettere[i] != lettere[j]){
            found = 0;
        }
        i++;
        j--;
    }

    if(found == 1)
        printf("la stringa e' palindroma\n");
    else
        printf("la stringa non e' palindroma\n");

    return 0;
}
